import uuid

import pika


